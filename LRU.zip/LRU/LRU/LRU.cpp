#include<stdlib.h>
#include<GL/glut.h>
#include<stdio.h>
#include<string.h>
#include<math.h>
#define SCENE 10
int request[9]/*={0}*/,counter[3]={0},pages[3]={0}, fault[9]={0}, colour[9]={1,1,1,1,1,1,1,1,1}, pagecolour[3]={1,1,1};
float assign[9]={-5.5,-5.5,-5.5,-5.5,-5.5,-5.5,-5.5,-5.5,-5.5};
int dest=0, showresult=0,n1;
//int request[n1]; //it was not there
int step=-1, startani=0, faults=0;
char res[]="No. of page faults =  ";
float bgcolor[][3]={{1,0,0},{0,1,0},{0,0,1}};
int bgpointer=0;
float tilecolor[][3]={{1,1,0},{1,0.7,0.7},{0,1,1}};
int tilepointer=0;
void *fonts[]=
{
GLUT_BITMAP_9_BY_15,
GLUT_BITMAP_TIMES_ROMAN_10,
GLUT_BITMAP_TIMES_ROMAN_24,
GLUT_BITMAP_HELVETICA_12,
GLUT_BITMAP_HELVETICA_10,
GLUT_BITMAP_HELVETICA_18,
};
void output(int x,int y,char *string,int j)
{
int len,i;
glColor3f(1.0f,0.0f,0.0f);
glRasterPos2f(x,y);
len=(int) strlen(string);
for(i=0;i<len;i++)
glutBitmapCharacter(fonts[j],string[i]);
}
void front_page()
{
glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
glMatrixMode(GL_MODELVIEW);
glPushMatrix();
output(250,500,"Sapthagiri college of Engineering",2);
output(200,450," Department of Computer Science Engineering",2);
output(150,400,"Computer Graphics Laboratory with Mini Project[18CSL67]",2);
//output(320,350,"   A   ",2);
//output(280,300,"MINI PROJECT ON",2);
//output(220,250,"LRU PAGE REPLACEMENT ALGORITHM",2);
//output(100,150,"Guide:",3);
output(130,330,"Preetha S Jois                    [1SG18CS075]",5);
output(130,300,"Yashaswini M Kotegar        [1SG18CS128]",5);
output(130,250,"Guide",3);   
output(200,230,"Mr. S Suresh Kumar ",5);
output(210,210,"M.Tech (Ph.D)",5);
output(210,190,"Assistant Proffesor",5);
output(450,230,"Mrs. Anuradha Badage ",5);
output(460,210,"B.E M.Tech",5);
output(460,190,"Assistant Proffesor",5);
output(275,50,"-> PRESS C or c to CONTINUE",2);
output(275,100,"-> PRESS Q or q to QUIT",2);
glFlush();
glCallList(SCENE);
glPopMatrix();
glutSwapBuffers();
}
void init()
{
	glColor3f(0,0,0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0,800,0,600);
	glMatrixMode(GL_MODELVIEW);
}
int getLRU()
{
	if(counter[0]>=counter[1] && counter[0]>=counter[2]) return 0;
	if(counter[1]>=counter[0] && counter[1]>=counter[2]) return 1;
	//if(counter[2]>=counter[1] && counter[2]>=counter[3]) return 2;
	return 2;
}
void tile(float x, float y, char n)
{
	float size=20;
	//glColor3f(1,1,0);
	glBegin(GL_POLYGON);
	glVertex2f(x-size, y-size);
	glVertex2f(x+size, y-size);
	glVertex2f(x+size, y+size);
	glVertex2f(x-size, y+size);
	glEnd();
	glColor3f(0,0,0);
	glBegin(GL_LINE_LOOP);
	glVertex2f(x-size, y-size);
	glVertex2f(x+size, y-size);
	glVertex2f(x+size, y+size);
	glVertex2f(x-size, y+size);
	glEnd();
	glRasterPos2f(x-size/2, y);
	glutBitmapCharacter(GLUT_BITMAP_9_BY_15, n);
}
void draw_flag()
{
	glColor3fv(bgcolor[bgpointer]);
	glBegin(GL_POLYGON);
	glVertex2f(-10,-10);
	glVertex2f(10,-10);
	glVertex2f(10,10);
	glVertex2f(-10,10);
	glEnd();
}
void setup_request()
{
	int i;
	glColor3fv(bgcolor[bgpointer]);
	glBegin(GL_POLYGON);
	glVertex2f(0,0);
	glVertex2f(700,0);
	glVertex2f(700,100);
	glVertex2f(0,100);
	glEnd();
	glPushMatrix();
	glTranslatef(-10, 40, 0);
	for(i=0; i<n1; i++) //it was 9
	{
		glColor3fv(tilecolor[tilepointer]);
		glTranslatef(70, 0, 0);
		glPushMatrix();
		if(assign[i]>-4.5)
		{
			glTranslatef(70*step-70*i,0,0);
		}
		glTranslatef(0, -250-45*assign[i], 0);

		if((int)assign[i]==dest && assign[i]>=0)
				glColor3f(1,0.3,0.3);
		else
			//glColor3f(colour[i],1,0);
			glColor3fv(tilecolor[tilepointer]);

		tile(10,10,request[i]+'0');
		glPopMatrix();
		if(fault[i])
		{
		glPushMatrix();
		glTranslatef(0, -385, 0);
		draw_flag();
		glPopMatrix();
		}
	}
	glPopMatrix();
}
void drawText(char *string,float x,float y,float z) 
{  
char *c;
glRasterPos3f(x, y,z);
for (c=string; *c != '\0'; c++) 
{
	if(*c=='\n')
	glRasterPos3f(x, y-0.05,z);
	else
	glutBitmapCharacter(GLUT_BITMAP_9_BY_15, *c);
}
}
void setup_pages()
{
	glPushMatrix();
	//glColor3f(fabs(sin(ycolour[1])), 1, 0);
//	glColor3f(1, pagecolour[0], 0);
	tile(0,0,pages[0]==0?' ':pages[0]+'0');
	glTranslatef(0, -45, 0);
//	glColor3f(fabs(sin(ycolour[2])), 1, 0);
	//glColor3f(1, pagecolour[1], 0);
	tile(0,0,pages[1]==0?' ':pages[1]+'0');
	glTranslatef(0, -45, 0);
//	glColor3f(fabs(sin(ycolour[3])), 1, 0);
	//glColor3f(1, pagecolour[2], 0);
	tile(0,0,pages[2]==0?' ':pages[2]+'0');
	glPopMatrix();
}
void display()
{
	glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();
	glPushMatrix();
	glTranslatef(120+70*step,200,0);
	setup_pages();
	glPopMatrix();
	glColor3f(1,1,0);
	glPushMatrix();
	glTranslatef(50, 400, 0);
	setup_request();
	glPopMatrix();
	glEnd();
	if(showresult && step==n1-1) //it was 8
	{
		glColor3f(0,0,0);
		res[21]=faults+'0';
		drawText(res, 50, 20, 0);
	}
		drawText("LRU Page Replacement Algorithm", 250, 550, 0);
	glFlush();
	glutSwapBuffers();
}
void idle()
{
	if(!startani)
		return;
	if(dest>assign[step])
	assign[step]+=0.01;
	if(dest<=assign[step])
	{
		if(fault[step])
		pages[dest]=request[step];	
		startani=0;
		dest=-10;
		showresult=1;
	}
	display();
}
void mouse(int btn,int state,int x, int y)
{

	int n,i,j;
	if(startani==1)
		return;
	if(btn==GLUT_LEFT_BUTTON && state==GLUT_DOWN &&step<n1-1)//it was 8
	{
		if(step<n1) //it was <n
			step++;
		for(i=0;i<3;i++)
		{
			if(request[step]==pages[i])
			{
				fault[step]=0;
				counter[i]=0;
				for(j=0;j<3;j++)
					if(j!=i) counter[j]++;
				//dest=i;
					dest=-5;
				startani=1;
				colour[step]=0;
				glutPostRedisplay();
					return;
			}
		}
		n=getLRU();
		counter[n]=0;
		for(i=0;i<3;i++)
			if(i!=n)
			counter[i]++;
		//pagecolour[n]=0;
		//assign[step]=n;
			dest=n;
			startani=1;
		fault[step]=1;
		faults++;
	}
	glutPostRedisplay();
}
void handle_bg_colour(int action)
{
	bgpointer=action;
	glutPostRedisplay();
}
void handle_tile_colour(int action)
{
	tilepointer=action;
	glutPostRedisplay();
}
void menu(int action)
{
	if(action==0)
		exit(0);
}
void addMenu()
{
	int submenu1, submenu2;

	submenu1 = glutCreateMenu(handle_bg_colour);
	glutAddMenuEntry("Red",0);
	glutAddMenuEntry("Green",1);
	glutAddMenuEntry("Blue",2);
	submenu2 = glutCreateMenu(handle_tile_colour);
	glutAddMenuEntry("Yellow",0);
	glutAddMenuEntry("Light Red",1);
	glutAddMenuEntry("Light Blue",2);
	glutCreateMenu(menu);
	glutAddSubMenu("Background Colour",submenu1);
	glutAddSubMenu("Tile Colour",submenu2);
	glutAddMenuEntry("Quit",0);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
}

/*void display1()		//we hv commented
{
glClearColor(1.0,1.0,1.0,1.0);
glClear(GL_COLOR_BUFFER_BIT);
front_page();
glFlush();
glutSwapBuffers();
}
*/

void dis()
{
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	glColor3f(1,0,0);
	glRasterPos2f(50,550);
	char msg[]="Least Recently Used page replacement algorithm keeps track of page usage over a short period";
	for(int i =0;i<strlen(msg);i++)
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, msg[i]);

	glRasterPos2f(50,500);
	char msg1[]="of time. It works on the idea that the pages that have been most heavily used in the past are"; 
	for(int i =0;i<strlen(msg1);i++)
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, msg1[i]);

	glRasterPos2f(50,450);
	char msg2[]="most likely to be used heavily in the future too. ";
	for(int i =0;i<strlen(msg2);i++)
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, msg2[i]);

	glRasterPos2f(50,400);
	char msg21[]="In LRU, whenever page replacement happens, the page which has not been used for the "; 
	for(int i =0;i<strlen(msg21);i++)
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, msg21[i]);

	glRasterPos2f(50,350);
	char msg22[] = "longest amount of time is replaced. The maximum number of pages that can be requested is 9";
	for(int i =0;i<strlen(msg22);i++)
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, msg22[i]);

	glColor3f(1,0,0);
	glRasterPos2f(50,300);
	char msg3[]="ADVANTAGES";
	for(int i =0;i<strlen(msg3);i++)
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, msg3[i]);

	glRasterPos2f(50,250);
	char msg4[]="	* Efficient";
	for(int i =0;i<strlen(msg4);i++)
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, msg4[i]);

	glRasterPos2f(50,200);
	char msg5[]="	* Doesn't suffer from Belady�s Anomaly";
	for(int i =0;i<strlen(msg5);i++)
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, msg5[i]);

	glColor3f(0,0,1);
	glRasterPos2f(50,100);
	char msg6[]="Click anywhere on the screen to start LRU page replacement algorithm (Mouse function)";
	for(int i =0;i<strlen(msg6);i++)
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, msg6[i]);

	
	glRasterPos2f(50,50);
	char msg7[]="Enter S or s to start (Key function)";
	for(int i =0;i<strlen(msg7);i++)
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, msg7[i]);

	
	glRasterPos2f(50,20);
	char msg8[]="Enter Q or q to Quit (Key function)";
	for(int i =0;i<strlen(msg8);i++)
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, msg8[i]);

	glutMouseFunc(mouse);
	glutSwapBuffers();
	
}

void key(unsigned char key,int x,int y)
{
switch(key)
{
case 'S':
case 's':glutDisplayFunc(display);
break;
case 'Q':
case 'q':exit(0);
case 'C': 
case 'c': glutDisplayFunc(dis);
	break;
}
glutPostRedisplay();
}
int main(int argc, char** argv)
{
	
	glutInit(&argc,argv);
	
	int i;
	printf("Enter the number of page requests (maximum of 9)");
	scanf("%d",&n1);
	printf("Enter a sequence of %d numbers for page request\n",n1);
	for(i=0; i<n1; i++)
		scanf("%d", &request[i]);
	
	glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB);
	glutInitWindowSize(1000,800);
	glutCreateWindow("LRU- page replacement ");
	glutKeyboardFunc(key);
   // glutDisplayFunc(display1);		//hv to put to commrnt
		
	glutDisplayFunc(front_page); 		//initially was in comment
	//glutDisplayFunc(dis);
	//glutDisplayFunc(display);
	     
	glutIdleFunc(idle);
	glClearColor(1,1,1,1);
	init();
	addMenu();
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0,800,0,600);
	glMatrixMode(GL_MODELVIEW);
	glutMainLoop();
return 0;
}